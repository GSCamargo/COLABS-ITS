<html>
<head> 
    <title>COLABS - Login</title> 
    <link rel="stylesheet" href="Style/Login/loginpage.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="logo.png" class="logo">
        </div>
    </div>

    <div class="content">
        <h1>COLABS</h1>
        <h1>TEKNIK KOMPUTER ITS</h1>
        <form>
            <label>Username</label><br>
            <li><a href="#"></a><input type="text"><br></a></li>
            <label>Password</label><br>
            <li><a href="#"><input type="password"><br></a></li>
            <button type="button"><span></span>LOGIN</button>
        </form>
    </div>
</body>
</html>